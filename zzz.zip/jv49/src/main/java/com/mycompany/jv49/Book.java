/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.jv49;

/**
 *
 * @author 40MINH KHAI
 */    
public final class Book {
	private String name;
	private final Author[] authors;
	private double price;
	
	public Book(String name,Author[] authors, double price) {
		this.authors=authors;
		this.setName(name);
		this.setPrice(price);
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}
	public String getAuthorNames() {
		String authorNames= "" ;
		for (int i=0; i< authors.length-1;i++) {
			authorNames += authors[i].getName() + ", ";
		}
			authorNames += authors[authors.length -1].getName() ;
		return authorNames;
	}
	

}

